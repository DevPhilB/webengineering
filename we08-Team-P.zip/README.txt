Aufgabe1
- In style.css 
 - relative Größe verwendet.
 - Order hinzugefügt.

Aufgabe2
- In style.css alles da und kommentiert.

Aufgabe3
- In style.css alles da und kommentiert.